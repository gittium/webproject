<?php
session_start();
include 'config.php';

// ในส่วนบนสุดของ checkout.php
if (!isset($_SESSION['user_id'])) {
    // สำหรับการทดสอบ กำหนดค่า user_id เป็น 1
    $_SESSION['user_id'] = 1; // ตรวจสอบว่ามีผู้ใช้ที่มี user_id = 1 ในตาราง users
}

$user_id = $_SESSION['user_id'];

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบหรือไม่
// if (!isset($_SESSION['user_id'])) {
//     // ถ้าไม่ได้เข้าสู่ระบบ ให้เปลี่ยนเส้นทางไปยังหน้าเข้าสู่ระบบ
//     header('Location: login.php');
//     exit();
// }

// $user_id = $_SESSION['user_id'];

// ตรวจสอบว่าตะกร้าสินค้าไม่ว่าง
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $total_amount = 0;
    foreach ($_SESSION['cart'] as $product_id => $product) {
        $total_amount += $product['price'] * $product['quantity'];
    }

    // เริ่มการทำธุรกรรม
    $conn->begin_transaction();

    try {
        // เพิ่มข้อมูลลงในตาราง orders
        $stmt_order = $conn->prepare("INSERT INTO orders (user_id, total_amount, order_status) VALUES (?, ?, 'pending')");
        if (!$stmt_order) {
            echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
            exit();
        }
        $stmt_order->bind_param("id", $user_id, $total_amount);
        if (!$stmt_order->execute()) {
            echo "Execute failed: (" . $stmt_order->errno . ") " . $stmt_order->error;
            $conn->rollback();
            exit();
        }
        $order_id = $stmt_order->insert_id;
        $stmt_order->close();


        // เพิ่มรายการสินค้าลงในตาราง order_items
        $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        if (!$stmt_item) {
            echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
            $conn->rollback();
            exit();
        }

        foreach ($_SESSION['cart'] as $product_id => $product) {
            $quantity = $product['quantity'];
            $price = $product['price'];
            $stmt_item->bind_param("iiid", $order_id, $product_id, $quantity, $price);
            if (!$stmt_item->execute()) {
                echo "Execute failed: (" . $stmt_item->errno . ") " . $stmt_item->error;
                $conn->rollback();
                exit();
            }
        }
        $stmt_item->close();


        // ยืนยันการทำธุรกรรม
        $conn->commit();

        // ล้างตะกร้าสินค้า
        unset($_SESSION['cart']);

        // แสดงข้อความยืนยันคำสั่งซื้อ
        echo "สั่งซื้อสำเร็จ! หมายเลขคำสั่งซื้อของคุณคือ #" . $order_id;
        header('Location: order_confirmation.php?order_id=' . $order_id);
        exit();
        // คุณอาจเปลี่ยนเส้นทางไปยังหน้าขอบคุณหรือหน้ารายละเอียดคำสั่งซื้อ
    } catch (Exception $e) {
        // ยกเลิกการทำธุรกรรมหากมีข้อผิดพลาด
        $conn->rollback();
        echo "เกิดข้อผิดพลาดในการสั่งซื้อ: " . $e->getMessage();
    }
} else {
    echo "ตะกร้าสินค้าของคุณว่างเปล่า";
}

$conn->close();
?>
