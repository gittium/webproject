<?php
session_start();

if (isset($_POST['product_id'], $_POST['action'])) {
    $product_id = intval($_POST['product_id']);
    $action = $_POST['action'];

    if (isset($_SESSION['cart'][$product_id])) {
        if ($action == 'increase') {
            $_SESSION['cart'][$product_id]['quantity'] += 1;
        } elseif ($action == 'decrease') {
            $_SESSION['cart'][$product_id]['quantity'] -= 1;
            if ($_SESSION['cart'][$product_id]['quantity'] <= 0) {
                unset($_SESSION['cart'][$product_id]);
            }
        } elseif ($action == 'remove') {
            unset($_SESSION['cart'][$product_id]);
        }
    }
}

header('Location: cart.php');
exit();
?>
