<?php
session_start();
include 'config.php';

if (isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);

    // ดึงข้อมูลสินค้าจากฐานข้อมูล
    $stmt = $conn->prepare("SELECT name, price FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($product = $result->fetch_assoc()) {
        // ตรวจสอบว่ามีตะกร้าสินค้าอยู่แล้วหรือไม่
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = array();
        }

        // เพิ่มหรืออัปเดตสินค้าที่เลือกในตะกร้า
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] += 1;
        } else {
            $_SESSION['cart'][$product_id] = array(
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => 1
            );
        }

        // เปลี่ยนเส้นทางกลับไปยังหน้า product.php หรือแสดงข้อความยืนยัน
        header('Location: product.php');
        exit();
    } else {
        echo "ไม่พบสินค้า";
    }

    $stmt->close();
} else {
    echo "ไม่มีข้อมูลสินค้า";
}

$conn->close();
?>
