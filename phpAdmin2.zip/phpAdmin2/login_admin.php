<?php
session_start();
@include 'config.php';

$message = array();

if(isset($_POST['login'])){
    $admin_username = mysqli_real_escape_string($conn, $_POST['admin_username']);
    $admin_password = $_POST['admin_password'];

    if(empty($admin_username) || empty($admin_password)){
        $message[] = 'Please fill out all fields';
    } else {
        $query = "SELECT * FROM admins WHERE username = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $admin_username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) === 1){
            $row = mysqli_fetch_assoc($result);
            // Verify password
            if(password_verify($admin_password, $row['password'])){
                // Set session variables
                $_SESSION['admin_username'] = $admin_username;
                header('Location: admin_page.php');
                exit();
            } else {
                $message[] = 'Incorrect password';
            }
        } else {
            $message[] = 'Username not found';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content -->
    <title>Admin Login</title>
    <!-- Include your CSS files -->
</head>
<body>
    <?php
    if(isset($message)){
        foreach($message as $msg){
            echo '<span class="message">'.$msg.'</span>';
        }
    }
    ?>

    <form action="" method="post">
        <h2>Admin Login</h2>
        <input type="text" name="admin_username" placeholder="Username" required>
        <input type="password" name="admin_password" placeholder="Password" required>
        <input type="submit" name="login" value="Login">
    </form>
</body>
</html>
